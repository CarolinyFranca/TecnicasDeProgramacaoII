package br.com.fatecararas.domain;

public class Lagarto extends Algoritmo {
    @Override
    public String executar(TipoAlgoritmo tipo) {

        switch (tipo) {
            case PEDRA -> {
                return "Perdeu! Pedra esmaga o lagarto";
            }
            case PAPEL -> {
                return "Ganhou! Lagarto como o papel";
            }
            case TESOURA -> {
                return "Perdeu! Tesoura decapita lagarto";
            }
            case LAGARTO -> {
                return "Empatou! Lagarto empata com lagarto";
            }
            case SPOCK -> {
                return "Ganhou! Lagarto envenena spock";
            }
            default -> {
                return "Empatou! Tipo inválido";
            }
        }
    }
}
