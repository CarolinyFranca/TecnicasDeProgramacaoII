package br.com.fatecararas;

import br.com.fatecararas.domain.Algoritmo;
import br.com.fatecararas.domain.Jokenpo;
import br.com.fatecararas.domain.TipoAlgoritmo;

import java.util.Random;
import java.util.Scanner;

import static br.com.fatecararas.domain.TipoAlgoritmo.*;

public class Main {
    public static void main(String[] args) throws IllegalAccessException {

        Scanner in = new Scanner(System.in);
        System.out.println("Escolha uma das opções [ 1-PEDRA, 2-PAPEL, 3-TESOURA, 4-LAGARTO, 5-SPOCK ]\n");
        int jogada = in.nextInt();

        Algoritmo jogadaJogador = Algoritmo.converterAlgoritmo(jogada);

        int computador = new Random().nextInt(5) + 1;

        TipoAlgoritmo algoritmoComputador = getTipo(computador);
        System.out.println("\n A máquina escolheu: " + algoritmoComputador + "\n");

        var jokenpo = new Jokenpo();

        jokenpo.setAlgortimo(jogadaJogador);
        jokenpo.jogar(algoritmoComputador);

        in.close();
    }
}