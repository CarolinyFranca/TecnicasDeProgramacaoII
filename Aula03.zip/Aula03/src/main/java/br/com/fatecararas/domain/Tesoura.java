package br.com.fatecararas.domain;

public class Tesoura extends Algoritmo {
    @Override
    public String executar(TipoAlgoritmo tipo) {

        switch (tipo) {
            case PEDRA -> {
                return "Perdeu! Pedra esmaga tesoura";
            }
            case PAPEL -> {
                return "Ganhou! Tesoura corta o papel";
            }
            case TESOURA -> {
                return "Empatou! Tesoura empata com tesoura";
            }
            case LAGARTO -> {
                return "Ganhou! Tesoura decapita o lagarto";
            }
            case SPOCK -> {
                return "Perdeu! Spock esmaga tesoura";
            }
            default -> {
                return "Empatou! Tipo inválido";
            }
        }
    }
}
