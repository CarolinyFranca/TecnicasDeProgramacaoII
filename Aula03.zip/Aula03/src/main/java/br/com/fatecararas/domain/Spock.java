package br.com.fatecararas.domain;

public class Spock extends Algoritmo {
    @Override
    public String executar(TipoAlgoritmo tipo) {

        switch (tipo) {
            case PEDRA -> {
                return "Ganhou! Spock vaporiza a pedra";
            }
            case PAPEL -> {
                return "Perdeu! Papel refuta spock";
            }
            case TESOURA -> {
                return "Ganhou! Spock esmaga a tesoura";
            }
            case LAGARTO -> {
                return "Perdeu! Lagarto envenena o spock";
            }
            case SPOCK -> {
                return "Empatou! Spock empata com spock";
            }
            default -> {
                return "Empatou! Tipo inválido";
            }
        }
    }
}
