package br.com.fatecararas.domain;

public class Pedra extends Algoritmo {
    @Override
    public String executar(TipoAlgoritmo tipo) {

        switch (tipo) {
            case PEDRA -> {
                return "Empatou! Pedra empata com pedra";
            }
            case PAPEL -> {
                return "Perdeu! Papel embrulha a pedra ";
            }
            case TESOURA -> {
                return "Ganhou! Pedra esmaga a tesoura";
            }
            case LAGARTO -> {
                return "Ganhou! Pedra esmaga o lagarto";
            }
            case SPOCK -> {
                return "Perdeu! Spock vaporiza pedra";
            }
            default -> {
                return "Empatou! Tipo inválido";
            }
        }
    }
}
