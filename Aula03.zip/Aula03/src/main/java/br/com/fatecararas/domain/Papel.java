package br.com.fatecararas.domain;

public class Papel extends Algoritmo {
    @Override
    public String executar(TipoAlgoritmo tipo) {

        switch (tipo) {
            case PEDRA -> {
                return "Ganhou! Papel embrulha a pedra!";
            }            
            case PAPEL -> {
                return "Empatou! Papel empata com papel";
            }
            case TESOURA -> {
                return "Perdeu! Tesoura corta o papel!";
            }
            case LAGARTO -> {
                return "Perdeu! lagarto come papel";
            }
            case SPOCK -> {
                return "Ganhou! Papel refuta Spock";
            }
            default -> {
                return "Empatou! Tipo inválido";
            }
        }
    }
}
